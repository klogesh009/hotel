import { useState, useEffect } from 'react'
import { Link } from 'react-router-dom'
import { Edit, Trash2, Search, IndianRupee } from 'lucide-react'

function FoodList() {
  const [foods, setFoods] = useState([])
  const [searchTerm, setSearchTerm] = useState('')
  const [filterCategory, setFilterCategory] = useState('all')

  useEffect(() => {
    const savedFoods = localStorage.getItem('foodItems')
    if (savedFoods) {
      setFoods(JSON.parse(savedFoods))
    } else {
      // Initialize with sample South Indian foods
      const sampleFoods = [
        {
          id: 1,
          name: 'Dosa',
          category: 'Breakfast',
          price: 80,
          description: 'Crispy fermented crepe made from rice and urad dal',
          image: 'https://images.unsplash.com/photo-1585937421612-70a008356fbe?w=800&h=600&fit=crop',
          available: true
        },
        {
          id: 2,
          name: 'Idli',
          category: 'Breakfast',
          price: 60,
          description: 'Steamed rice cakes served with sambar and chutney',
          image: 'https://images.unsplash.com/photo-1603133872878-684f208fb84b?w=800&h=600&fit=crop',
          available: true
        },
        {
          id: 3,
          name: 'Sambar',
          category: 'Curry',
          price: 120,
          description: 'Spicy lentil stew with vegetables and tamarind',
          image: 'https://images.unsplash.com/photo-1585937421612-70a008356fbe?w=800&h=600&fit=crop',
          available: true
        },
        {
          id: 4,
          name: 'Biryani',
          category: 'Main Course',
          price: 250,
          description: 'Fragrant basmati rice cooked with spices and meat/vegetables',
          image: 'https://images.unsplash.com/photo-1563379091339-03246963d29c?w=800&h=600&fit=crop',
          available: true
        },
        {
          id: 5,
          name: 'Vada',
          category: 'Snacks',
          price: 50,
          description: 'Deep-fried savory donut made from urad dal',
          image: 'https://images.unsplash.com/photo-1603133872878-684f208fb84b?w=800&h=600&fit=crop',
          available: true
        },
        {
          id: 6,
          name: 'Rasam',
          category: 'Soup',
          price: 90,
          description: 'Tangy and spicy soup made with tamarind and tomatoes',
          image: 'https://images.unsplash.com/photo-1585937421612-70a008356fbe?w=800&h=600&fit=crop',
          available: true
        }
      ]
      setFoods(sampleFoods)
      localStorage.setItem('foodItems', JSON.stringify(sampleFoods))
    }
  }, [])

  const handleDelete = (id) => {
    if (window.confirm('Are you sure you want to delete this item?')) {
      const updatedFoods = foods.filter(food => food.id !== id)
      setFoods(updatedFoods)
      localStorage.setItem('foodItems', JSON.stringify(updatedFoods))
    }
  }

  const toggleAvailability = (id) => {
    const updatedFoods = foods.map(food =>
      food.id === id ? { ...food, available: !food.available } : food
    )
    setFoods(updatedFoods)
    localStorage.setItem('foodItems', JSON.stringify(updatedFoods))
  }

  const categories = ['all', ...new Set(foods.map(food => food.category))]

  const filteredFoods = foods.filter(food => {
    const matchesSearch = food.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         food.description.toLowerCase().includes(searchTerm.toLowerCase())
    const matchesCategory = filterCategory === 'all' || food.category === filterCategory
    return matchesSearch && matchesCategory
  })

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="mb-8">
        <h1 className="text-4xl font-bold text-white mb-2 text-center">Food Menu</h1>
        <p className="text-white/80 text-center">Manage your South Indian cuisine menu</p>
      </div>

      {/* Search and Filter */}
      <div className="bg-white/10 backdrop-blur-md rounded-2xl p-6 mb-8 shadow-xl">
        <div className="flex flex-col md:flex-row gap-4">
          <div className="flex-1 relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-white/60 w-5 h-5" />
            <input
              type="text"
              placeholder="Search food items..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full pl-10 pr-4 py-3 rounded-lg bg-white/20 backdrop-blur-sm text-white placeholder-white/60 border border-white/30 focus:outline-none focus:ring-2 focus:ring-yellow-400"
            />
          </div>
          <select
            value={filterCategory}
            onChange={(e) => setFilterCategory(e.target.value)}
            className="px-4 py-3 rounded-lg bg-white/20 backdrop-blur-sm text-white border border-white/30 focus:outline-none focus:ring-2 focus:ring-yellow-400"
          >
            {categories.map(cat => (
              <option key={cat} value={cat} className="bg-gray-800">
                {cat.charAt(0).toUpperCase() + cat.slice(1)}
              </option>
            ))}
          </select>
        </div>
      </div>

      {/* Food Grid */}
      {filteredFoods.length === 0 ? (
        <div className="text-center py-16">
          <p className="text-white/80 text-xl">No food items found</p>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredFoods.map(food => (
            <div
              key={food.id}
              className={`bg-white/10 backdrop-blur-md rounded-2xl overflow-hidden shadow-xl transition transform hover:scale-105 ${
                !food.available ? 'opacity-60' : ''
              }`}
            >
              <div className="relative h-48 overflow-hidden">
                <img
                  src={food.image}
                  alt={food.name}
                  className="w-full h-full object-cover"
                  onError={(e) => {
                    e.target.src = 'https://images.unsplash.com/photo-1546069901-ba9599a7e63c?w=800&h=600&fit=crop'
                  }}
                />
                <div className="absolute top-4 right-4">
                  <span className={`px-3 py-1 rounded-full text-xs font-semibold ${
                    food.available
                      ? 'bg-green-500 text-white'
                      : 'bg-red-500 text-white'
                  }`}>
                    {food.available ? 'Available' : 'Unavailable'}
                  </span>
                </div>
              </div>
              <div className="p-6">
                <div className="flex items-start justify-between mb-2">
                  <h3 className="text-2xl font-bold text-white">{food.name}</h3>
                  <span className="text-yellow-400 font-bold text-xl flex items-center">
                    <IndianRupee className="w-5 h-5" />
                    {food.price}
                  </span>
                </div>
                <p className="text-white/70 text-sm mb-2">{food.category}</p>
                <p className="text-white/80 mb-4 line-clamp-2">{food.description}</p>
                <div className="flex items-center justify-between gap-2">
                  <button
                    onClick={() => toggleAvailability(food.id)}
                    className={`flex-1 px-4 py-2 rounded-lg font-semibold transition ${
                      food.available
                        ? 'bg-red-500 hover:bg-red-600 text-white'
                        : 'bg-green-500 hover:bg-green-600 text-white'
                    }`}
                  >
                    {food.available ? 'Mark Unavailable' : 'Mark Available'}
                  </button>
                  <Link
                    to={`/edit/${food.id}`}
                    className="bg-blue-500 hover:bg-blue-600 text-white px-4 py-2 rounded-lg transition"
                  >
                    <Edit className="w-5 h-5" />
                  </Link>
                  <button
                    onClick={() => handleDelete(food.id)}
                    className="bg-red-500 hover:bg-red-600 text-white px-4 py-2 rounded-lg transition"
                  >
                    <Trash2 className="w-5 h-5" />
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}

      <div className="mt-8 text-center text-white/60">
        <p>Total Items: {foods.length} | Showing: {filteredFoods.length}</p>
      </div>
    </div>
  )
}

export default FoodList

