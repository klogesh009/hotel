import { useState, useEffect } from 'react'
import { useNavigate, useParams } from 'react-router-dom'
import { Save, ArrowLeft, Image as ImageIcon } from 'lucide-react'

function FoodForm() {
  const { id } = useParams()
  const navigate = useNavigate()
  const isEditMode = !!id

  const [formData, setFormData] = useState({
    name: '',
    category: 'Breakfast',
    price: '',
    description: '',
    image: '',
    available: true
  })

  const [imagePreview, setImagePreview] = useState('')

  useEffect(() => {
    if (isEditMode) {
      const foods = JSON.parse(localStorage.getItem('foodItems') || '[]')
      const food = foods.find(f => f.id === parseInt(id))
      if (food) {
        setFormData(food)
        setImagePreview(food.image)
      }
    }
  }, [id, isEditMode])

  const categories = ['Breakfast', 'Lunch', 'Dinner', 'Snacks', 'Curry', 'Soup', 'Main Course', 'Dessert']

  const handleChange = (e) => {
    const { name, value, type, checked } = e.target
    setFormData(prev => ({
      ...prev,
      [name]: type === 'checkbox' ? checked : value
    }))
  }

  const handleImageChange = (e) => {
    const value = e.target.value
    setFormData(prev => ({ ...prev, image: value }))
    setImagePreview(value)
  }

  const getRandomFoodImage = () => {
    const foodImages = [
      'https://images.unsplash.com/photo-1585937421612-70a008356fbe?w=800&h=600&fit=crop',
      'https://images.unsplash.com/photo-1603133872878-684f208fb84b?w=800&h=600&fit=crop',
      'https://images.unsplash.com/photo-1563379091339-03246963d29c?w=800&h=600&fit=crop',
      'https://images.unsplash.com/photo-1546069901-ba9599a7e63c?w=800&h=600&fit=crop',
      'https://images.unsplash.com/photo-1565299624946-b28f40a0ae38?w=800&h=600&fit=crop',
      'https://images.unsplash.com/photo-1565958011703-44f9829ba187?w=800&h=600&fit=crop'
    ]
    const randomImage = foodImages[Math.floor(Math.random() * foodImages.length)]
    setFormData(prev => ({ ...prev, image: randomImage }))
    setImagePreview(randomImage)
  }

  const handleSubmit = (e) => {
    e.preventDefault()
    
    if (!formData.name || !formData.price || !formData.description) {
      alert('Please fill in all required fields')
      return
    }

    const foods = JSON.parse(localStorage.getItem('foodItems') || '[]')
    
    if (isEditMode) {
      const updatedFoods = foods.map(food =>
        food.id === parseInt(id) ? { ...formData, id: parseInt(id), price: parseFloat(formData.price) } : food
      )
      localStorage.setItem('foodItems', JSON.stringify(updatedFoods))
    } else {
      const newId = foods.length > 0 ? Math.max(...foods.map(f => f.id)) + 1 : 1
      const newFood = {
        ...formData,
        id: newId,
        price: parseFloat(formData.price)
      }
      foods.push(newFood)
      localStorage.setItem('foodItems', JSON.stringify(foods))
    }

    navigate('/')
  }

  return (
    <div className="container mx-auto px-4 py-8 max-w-2xl">
      <div className="mb-6">
        <button
          onClick={() => navigate('/')}
          className="text-white hover:text-yellow-200 transition flex items-center space-x-2 mb-4"
        >
          <ArrowLeft className="w-5 h-5" />
          <span>Back to Menu</span>
        </button>
        <h1 className="text-4xl font-bold text-white mb-2">
          {isEditMode ? 'Edit Food Item' : 'Add New Food Item'}
        </h1>
        <p className="text-white/80">Manage your South Indian cuisine menu</p>
      </div>

      <form onSubmit={handleSubmit} className="bg-white/10 backdrop-blur-md rounded-2xl p-8 shadow-xl">
        {/* Image Preview */}
        {imagePreview && (
          <div className="mb-6">
            <img
              src={imagePreview}
              alt="Preview"
              className="w-full h-64 object-cover rounded-lg shadow-lg"
              onError={(e) => {
                e.target.src = 'https://images.unsplash.com/photo-1546069901-ba9599a7e63c?w=800&h=600&fit=crop'
              }}
            />
          </div>
        )}

        {/* Name */}
        <div className="mb-6">
          <label className="block text-white font-semibold mb-2">
            Food Name <span className="text-red-400">*</span>
          </label>
          <input
            type="text"
            name="name"
            value={formData.name}
            onChange={handleChange}
            placeholder="e.g., Dosa, Idli, Biryani"
            required
            className="w-full px-4 py-3 rounded-lg bg-white/20 backdrop-blur-sm text-white placeholder-white/60 border border-white/30 focus:outline-none focus:ring-2 focus:ring-yellow-400"
          />
        </div>

        {/* Category and Price */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
          <div>
            <label className="block text-white font-semibold mb-2">
              Category <span className="text-red-400">*</span>
            </label>
            <select
              name="category"
              value={formData.category}
              onChange={handleChange}
              required
              className="w-full px-4 py-3 rounded-lg bg-white/20 backdrop-blur-sm text-white border border-white/30 focus:outline-none focus:ring-2 focus:ring-yellow-400"
            >
              {categories.map(cat => (
                <option key={cat} value={cat} className="bg-gray-800">
                  {cat}
                </option>
              ))}
            </select>
          </div>
          <div>
            <label className="block text-white font-semibold mb-2">
              Price (₹) <span className="text-red-400">*</span>
            </label>
            <input
              type="number"
              name="price"
              value={formData.price}
              onChange={handleChange}
              placeholder="0.00"
              min="0"
              step="0.01"
              required
              className="w-full px-4 py-3 rounded-lg bg-white/20 backdrop-blur-sm text-white placeholder-white/60 border border-white/30 focus:outline-none focus:ring-2 focus:ring-yellow-400"
            />
          </div>
        </div>

        {/* Description */}
        <div className="mb-6">
          <label className="block text-white font-semibold mb-2">
            Description <span className="text-red-400">*</span>
          </label>
          <textarea
            name="description"
            value={formData.description}
            onChange={handleChange}
            placeholder="Describe the food item..."
            rows="4"
            required
            className="w-full px-4 py-3 rounded-lg bg-white/20 backdrop-blur-sm text-white placeholder-white/60 border border-white/30 focus:outline-none focus:ring-2 focus:ring-yellow-400 resize-none"
          />
        </div>

        {/* Image URL */}
        <div className="mb-6">
          <label className="block text-white font-semibold mb-2">
            Image URL
          </label>
          <div className="flex gap-2">
            <input
              type="url"
              name="image"
              value={formData.image}
              onChange={handleImageChange}
              placeholder="https://images.unsplash.com/..."
              className="flex-1 px-4 py-3 rounded-lg bg-white/20 backdrop-blur-sm text-white placeholder-white/60 border border-white/30 focus:outline-none focus:ring-2 focus:ring-yellow-400"
            />
            <button
              type="button"
              onClick={getRandomFoodImage}
              className="px-4 py-3 bg-purple-500 hover:bg-purple-600 text-white rounded-lg transition flex items-center space-x-2"
            >
              <ImageIcon className="w-5 h-5" />
              <span className="hidden md:inline">Random</span>
            </button>
          </div>
          <p className="text-white/60 text-sm mt-2">
            Leave empty or use a random image. Images are fetched from Unsplash.
          </p>
        </div>

        {/* Available Toggle */}
        <div className="mb-6">
          <label className="flex items-center space-x-3 cursor-pointer">
            <input
              type="checkbox"
              name="available"
              checked={formData.available}
              onChange={handleChange}
              className="w-5 h-5 rounded text-yellow-400 focus:ring-yellow-400 focus:ring-2"
            />
            <span className="text-white font-semibold">Available for order</span>
          </label>
        </div>

        {/* Submit Button */}
        <div className="flex gap-4">
          <button
            type="submit"
            className="flex-1 bg-yellow-400 hover:bg-yellow-500 text-gray-900 px-6 py-3 rounded-lg font-semibold transition shadow-lg flex items-center justify-center space-x-2"
          >
            <Save className="w-5 h-5" />
            <span>{isEditMode ? 'Update Food Item' : 'Add Food Item'}</span>
          </button>
          <button
            type="button"
            onClick={() => navigate('/')}
            className="px-6 py-3 bg-white/20 hover:bg-white/30 text-white rounded-lg font-semibold transition"
          >
            Cancel
          </button>
        </div>
      </form>
    </div>
  )
}

export default FoodForm

