import { useState, useEffect } from 'react'
import { BrowserRouter as Router, Routes, Route, Link, useLocation } from 'react-router-dom'
import FoodList from './components/FoodList'
import FoodForm from './components/FoodForm'
import { ChefHat, Plus, Home } from 'lucide-react'

function App() {
  return (
    <Router>
      <div className="min-h-screen bg-gradient-to-br from-purple-600 via-pink-500 to-red-500">
        <Navbar />
        <Routes>
          <Route path="/" element={<FoodList />} />
          <Route path="/add" element={<FoodForm />} />
          <Route path="/edit/:id" element={<FoodForm />} />
        </Routes>
      </div>
    </Router>
  )
}

function Navbar() {
  const location = useLocation()
  
  return (
    <nav className="bg-white/10 backdrop-blur-md shadow-lg sticky top-0 z-50 border-b border-white/20">
      <div className="container mx-auto px-4 py-4">
        <div className="flex items-center justify-between">
          <Link to="/" className="flex items-center space-x-2 text-white hover:text-yellow-200 transition">
            <ChefHat className="w-8 h-8" />
            <span className="text-2xl font-bold">South Indian Delights</span>
          </Link>
          <div className="flex items-center space-x-4">
            <Link
              to="/"
              className={`px-4 py-2 rounded-lg transition ${
                location.pathname === '/'
                  ? 'bg-white/20 text-white'
                  : 'text-white/80 hover:bg-white/10'
              }`}
            >
              <Home className="w-5 h-5 inline mr-2" />
              Menu
            </Link>
            <Link
              to="/add"
              className="bg-yellow-400 hover:bg-yellow-500 text-gray-900 px-6 py-2 rounded-lg font-semibold transition flex items-center space-x-2 shadow-lg"
            >
              <Plus className="w-5 h-5" />
              <span>Add Food</span>
            </Link>
          </div>
        </div>
      </div>
    </nav>
  )
}

export default App

